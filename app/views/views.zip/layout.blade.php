<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div id="container">
		@yield('content')
	</div>

	<script src="https://code.jquery.com/jquery-1.11.2.min.js"></script>
	<script type="text/javascript">
		@yield('script')
	</script>
</body>
</html>