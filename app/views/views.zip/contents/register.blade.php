@extends('layout')

@section('content')
    <form id="login_form_header">
    	<div class="form-group">
			{{ Form::text('username', '', ['class'=>'', 'placeholder'=>'Enter your username', 'required'=>'', 'autofocus'=>'']) }}
			<label class="" for="login-name"></label>
		</div>

		<div class="form-group">
			{{ Form::password('password', ['class'=>'', 'placeholder'=>'Password', 'required'=>'']) }}
			<label class="" for="login-pass"></label>
		</div>

		<div class="form-group">
			{{ Form::password('password_confirmation', ['class'=>'', 'placeholder'=>'Confirm Password', 'required'=>'']) }}
			<label class="" for="login-pass"></label>
		</div>

		<div class="form-group">
			{{ Form::text('type', '', ['class'=>'', 'placeholder'=>'Type', 'required'=>'', 'autofocus'=>'']) }}
			<label class="" for="login-name"></label>
		</div>



		<div class="form-group">
			{{ Form::text('first_name', '', ['class'=>'', 'placeholder'=>'Firstname', 'required'=>'', 'autofocus'=>'']) }}
			<label class="" for="login-name"></label>
		</div>

		<div class="form-group">
			{{ Form::text('last_name', '', ['class'=>'', 'placeholder'=>'Lastname', 'required'=>'', 'autofocus'=>'']) }}
			<label class="" for="login-name"></label>
		</div>

		<div class="form-group">
			{{ Form::text('home_lat', '', ['class'=>'', 'placeholder'=>'home_lat', 'required'=>'', 'autofocus'=>'']) }}
			<label class="" for="login-name"></label>
		</div>

		<div class="form-group">
			{{ Form::text('home_lng', '', ['class'=>'', 'placeholder'=>'home_lng', 'required'=>'', 'autofocus'=>'']) }}
			<label class="" for="login-name"></label>
		</div>

		<div class="form-group">
			{{ Form::text('birth_date', '', ['class'=>'', 'placeholder'=>'birth_date', 'required'=>'', 'autofocus'=>'']) }}
			<label class="" for="login-name"></label>
		</div>

		<div class="form-group">
			{{ Form::text('contact_number', '', ['class'=>'', 'placeholder'=>'contact_number', 'required'=>'', 'autofocus'=>'']) }}
			<label class="" for="login-name"></label>
		</div>

		<div class="form-group">
			{{ Form::text('gender', '', ['class'=>'', 'placeholder'=>'gender', 'required'=>'', 'autofocus'=>'']) }}
			<label class="" for="login-name"></label>
		</div>

		<div class="form-group">
			{{ Form::text('email', '', ['class'=>'', 'placeholder'=>'email', 'required'=>'', 'autofocus'=>'']) }}
			<label class="" for="login-name"></label>
		</div>

		<div class="form-group">
			{{ Form::text('deviceID', '', ['class'=>'', 'placeholder'=>'deviceID', 'required'=>'', 'autofocus'=>'']) }}
			<label class="" for="login-name"></label>
		</div>
	
		{{ Form::submit('Register', ['class'=>'btn btn-warning btn-lg btn-block']) }}
    </form>
@stop


@section('script')
$("#login_form_header").submit(function(event){

    event.preventDefault();

    $.ajax({
        url: 'register',
        data: $(this).serialize(),
        type: 'post',
        dataType: 'json',
        success: function(result){
            console.log(result);
        },
        error: function(e){
        	console.log("Could not retrieve login information");
        }
    });

    return false;
});
@stop